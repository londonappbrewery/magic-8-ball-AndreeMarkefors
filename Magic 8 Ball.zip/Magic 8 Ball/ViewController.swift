//
//  ViewController.swift
//  Magic 8 Ball
//
//  Created by Andree Markefors on 03.06.17.
//  Copyright © 2017 Andree Markefors. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ballOfAnswers: UIImageView!
    
    var currentAnswerIndex = 0
    
    let answersArray = ["ball1", "ball2", "ball3", "ball4", "ball5"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        hitMeWithAnAnswer()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func answerGeneratorButton(_ sender: UIButton) {
        
        hitMeWithAnAnswer()
        
    }
    
    func hitMeWithAnAnswer() {
        
        currentAnswerIndex = Int(arc4random_uniform(5))
        
        ballOfAnswers.image = UIImage (named: answersArray[currentAnswerIndex])
        
    }
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        
        hitMeWithAnAnswer()
    }
    
}

